import { useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { Search, ShoppingBag, Menu, X, User, Play, MessageCircle, Heart } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";

const Navbar = () => {
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const location = useLocation();

  const isActive = (path: string) => location.pathname === path;

  const leftNavItems = [
    { name: "Shop", path: "/shop" },
    { name: "About Us", path: "/about" },
    { name: "Home", path: "/" },
    { name: "Thrift", path: "/thrift" },
  ];

  return (
    <header className="border-b border-border bg-background sticky top-0 z-50">
      <div className="container-custom">
        <div className="flex h-16 items-center justify-between">
          {/* Desktop Left Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            {leftNavItems.map((item) => (
              <Link
                key={item.name}
                to={item.path}
                className={`text-sm font-medium transition-colors hover:text-primary ${
                  isActive(item.path) ? "text-primary border-b-2 border-primary" : "text-muted-foreground"
                }`}
              >
                {item.name}
              </Link>
            ))}
          </nav>

          {/* Centered Logo */}
          <div className="absolute left-1/2 transform -translate-x-1/2">
            <Link to="/" className="text-2xl font-serif font-semibold text-foreground hover:text-gray-600 transition-colors">
              VastraVibes
            </Link>
          </div>

          {/* Mobile Right Icons (Cart, Wishlist, Search) */}
          <div className="md:hidden flex items-center space-x-2">
            <Sheet open={isSearchOpen} onOpenChange={setIsSearchOpen}>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" className="h-8 w-8">
                  <Search className="h-4 w-4" />
                </Button>
              </SheetTrigger>
              <SheetContent side="left" className="w-80">
                <div className="flex flex-col space-y-6 mt-6">
                  <Link to="/" className="text-xl font-serif font-semibold">
                    VastraVibes
                  </Link>
                  
                  <nav className="flex flex-col space-y-4">
                    {leftNavItems.map((item) => (
                      <Link
                        key={item.name}
                        to={item.path}
                        className={`text-lg font-medium transition-colors hover:text-primary ${
                          isActive(item.path) ? "text-primary" : "text-muted-foreground"
                        }`}
                        onClick={() => setIsSearchOpen(false)}
                      >
                        {item.name}
                      </Link>
                    ))}
                  </nav>
                </div>
              </SheetContent>
            </Sheet>

            <Link to="/wishlist">
              <Button variant="ghost" size="icon" className="h-8 w-8">
                <Heart className="h-4 w-4" />
              </Button>
            </Link>

            <Link to="/cart">
              <Button variant="ghost" size="icon" className="relative h-8 w-8">
                <ShoppingBag className="h-4 w-4" />
                <span className="absolute -top-1 -right-1 h-3 w-3 bg-primary text-primary-foreground text-xs rounded-full flex items-center justify-center text-[10px]">
                  0
                </span>
              </Button>
            </Link>
          </div>

          {/* Desktop Right Icons */}
          <div className="hidden md:flex items-center space-x-1">
            <Link to="/reels">
              <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-foreground h-8 w-8">
                <Play className="h-4 w-4" />
              </Button>
            </Link>

            <Sheet open={isSearchOpen} onOpenChange={setIsSearchOpen}>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-foreground h-8 w-8">
                  <Search className="h-4 w-4" />
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="w-80">
                <div className="flex flex-col space-y-6 mt-6">
                  <h2 className="text-xl font-serif font-semibold">Navigation</h2>
                  
                  <nav className="flex flex-col space-y-4">
                    {leftNavItems.map((item) => (
                      <Link
                        key={item.name}
                        to={item.path}
                        className={`text-lg font-medium transition-colors hover:text-primary ${
                          isActive(item.path) ? "text-primary" : "text-muted-foreground"
                        }`}
                        onClick={() => setIsSearchOpen(false)}
                      >
                        {item.name}
                      </Link>
                    ))}
                  </nav>
                </div>
              </SheetContent>
            </Sheet>

            <Link to="/wishlist">
              <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-foreground h-8 w-8">
                <Heart className="h-4 w-4" />
              </Button>
            </Link>

            <Link to="/login">
              <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-foreground h-8 w-8">
                <User className="h-4 w-4" />
              </Button>
            </Link>

            <Link to="/cart">
              <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-foreground relative h-8 w-8">
                <ShoppingBag className="h-4 w-4" />
                <span className="absolute -top-1 -right-1 h-4 w-4 bg-primary text-primary-foreground text-xs rounded-full flex items-center justify-center">
                  0
                </span>
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Navbar;